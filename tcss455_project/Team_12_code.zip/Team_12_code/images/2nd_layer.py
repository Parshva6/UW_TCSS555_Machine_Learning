import cv2
from glob import glob
import os
import scipy.misc
import shutil


print("Begin")

filtered_training_img_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/2st_layer_eye_minNeighbor_5_to_3/'
if not os.path.exists(filtered_training_img_path):
    os.mkdir('2st_layer_eye_minNeighbor_5_to_3')

training_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/1st_layer_frontalface_alt_4_minNeighbor_5_to_0'

training_images = glob(os.path.join(training_image_path, '*.jpg'))

eye_cascade = cv2.CascadeClassifier("C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_eye.xml")

count = 0
for img in training_images:
    image_name = os.path.basename(img)
    img = cv2.imread(img, 0)
    count += 1
    print(count)

    for minNei in range(5, 3, -1): 
        eyes = eye_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
        
        if(len(eyes) > 0):
            shutil.copy(os.path.join(training_image_path, image_name), os.path.join(filtered_training_img_path, image_name))

print("Done")
