import random
import sys
import csv
import os
import warnings
import numpy as np
import pandas as pd
import tensorflow as tf
import xml.etree.ElementTree as et
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
from collections import Counter

import cv2
from glob import glob
import scipy.misc
import shutil
from pathlib import *

warnings.filterwarnings("ignore", category=FutureWarning)
pd.set_option('mode.chained_assignment', None)

#Command line args and setting up paths
input_directory = sys.argv[1]
output_directory = sys.argv[2]
profile_test = input_directory + "profile/profile.csv"
relation_test = input_directory + "relation/relation.csv"
train_text_dir = "/data/training/text/"
test_text_dir = input_directory + "text/"

#Loading Data frames
df_profile_test = pd.read_csv(profile_test,index_col=0)
df_relation_test = pd.read_csv(relation_test,index_col=0)
df_relation_test.like_id = df_relation_test.like_id.astype(str)
df_profile_train = pd.read_csv('/data/training/profile/profile.csv',index_col=0)
df_relation_train = pd.read_csv("/data/training/relation/relation.csv",index_col=0)
df_relation_train.like_id = df_relation_train.like_id.astype(str)


# Add agegroup column to profile dataframe
df_profile_train['agegroup'] = 0
df_profile_train['agegroup'].loc[df_profile_train['age']<25]=0
df_profile_train['agegroup'].loc[(df_profile_train['age']>=25) & (df_profile_train['age']<35)]=1
df_profile_train['agegroup'].loc[(df_profile_train['age']>=35) & (df_profile_train['age']<50)]=2
df_profile_train['agegroup'].loc[df_profile_train['age']>=50]=3

counts = df_relation_train['like_id'].value_counts()
new_df = df_relation_train[df_relation_train['like_id'].isin(counts[counts < 900].index & counts[counts > 1].index)]

# training data frame to apply NB and LR on likes
df_relation_grouped = new_df.groupby('userid',as_index=False).agg({'like_id': lambda x: "%s" % ' '.join(x)})
merge_df_train_relation = (pd.merge(df_profile_train, df_relation_grouped, left_on='userid', right_on='userid'))
df_relation_grouped2 = df_relation_test.groupby('userid',as_index=False).agg({'like_id': lambda x: "%s" % ' '.join(x)})
merge_df_test_relation = (pd.merge(df_profile_test, df_relation_grouped2, left_on='userid', right_on='userid'))

###############################################################################################
# LR on gender and age from text

df_profile_train["text"] = ""
ind = 0

for row in df_profile_train['userid']:
    text_file = row + ".txt"
    text_file = open(train_text_dir + text_file, 'rt',encoding="ISO-8859-1")
    text = text_file.read()
    df_profile_train.set_value(ind, "text", text)
    ind+=1
    text_file.close()

df_profile_test["text"] = ""
ind = 0

for row in df_profile_test['userid']:
    text_file = row + ".txt"
    text_file = open(test_text_dir + text_file, 'rt',encoding="ISO-8859-1")
    text = text_file.read()
    df_profile_test.set_value(ind, "text", text)
    ind+=1
    text_file.close()

# Add agegroup column to profile dataframe
df_profile_train['agegroup'] = 0
df_profile_train['agegroup'].loc[df_profile_train['age']<25]=0
df_profile_train['agegroup'].loc[(df_profile_train['age']>=25) & (df_profile_train['age']<35)]=1
df_profile_train['agegroup'].loc[(df_profile_train['age']>=35) & (df_profile_train['age']<50)]=2
df_profile_train['agegroup'].loc[df_profile_train['age']>=50]=3

gender_train = df_profile_train.loc[:,['text', 'gender']]
gender_test = df_profile_test.loc[:,['text', 'gender']]
age_train = df_profile_train.loc[:,['text', 'agegroup']]
age_test = df_profile_test.loc[:,['text', 'agegroup']]

# Training Naive Bayes model
count_vect = CountVectorizer()
X_gender_train = count_vect.fit_transform(gender_train['text'])
y_gender_train = gender_train['gender']
X_age_train = count_vect.fit_transform(age_train['text'])
y_age_train = age_train['agegroup']
clf_gender = LogisticRegression()
clf_gender.fit(X_gender_train, y_gender_train)
clf_age = LogisticRegression()
clf_age.fit(X_age_train, y_age_train)

# Predict test data
X_gender_test = count_vect.transform(gender_test['text'])
y_gender_LR_text = clf_gender.predict(X_gender_test)
X_age_test = count_vect.transform(age_test['text'])
y_age_LR_text = clf_age.predict(X_age_test)

###############################################################################################

# NB on age and gender based on likes

y_likes_gender_train = merge_df_train_relation['gender']
y_likes_age_train = merge_df_train_relation['agegroup']

count_vect2 = CountVectorizer()
X_train_age = count_vect2.fit_transform(merge_df_train_relation['like_id'])
X_test_age = count_vect2.transform(merge_df_test_relation['like_id'])
X_train_gender = count_vect2.fit_transform(merge_df_train_relation['like_id'])
X_test_gender = count_vect2.transform(merge_df_test_relation['like_id'])

clf_likes = MultinomialNB()
clf_likes.fit(X_train_gender, y_likes_age_train)
clf2_likes = MultinomialNB()
clf2_likes.fit(X_train_gender, y_likes_gender_train)
y_age_NB_likes = clf_likes.predict(X_test_age)
y_gender_NB_likes = clf2_likes.predict(X_test_gender)

###############################################################################################

# LR on age and gender based on likes

y_gender_likes = merge_df_train_relation['gender']

count_vect3 = CountVectorizer()
X_train_likes = count_vect3.fit_transform(merge_df_train_relation['like_id'])
X_test_likes = count_vect3.transform(merge_df_test_relation['like_id'])

clf_LR = LogisticRegression()
clf_LR.fit(X_train_likes, y_gender_likes)
y_gender_LR_likes = clf_LR.predict(X_test_likes)

y_age_likes = merge_df_train_relation['agegroup']

clf2_LR = LogisticRegression()
clf2_LR.fit(X_train_likes, y_age_likes)
y_age_LR_likes = clf2_LR.predict(X_test_likes)


###############################################################################################

gender_values = []
age_values = []
price = 0
index = 0
index1 = 0

for a, b, c in zip(y_age_LR_likes, y_age_NB_likes, y_age_LR_text):
    temp = [a,b,c]
    count = Counter(temp)
    i = count.most_common()[0][0]
    if i==0:
        age_values.append('xx-24')
    elif i==1:
        age_values.append('25-34')
    elif i==2:
        age_values.append('35-49')
    else:
        age_values.append('50-xx')
    index += 1

for a, b, c in zip(y_gender_LR_text, y_gender_LR_likes, df_profile_test['userid']):
    temp = [a, b]
    if temp==[0.0, 0.0]:
        gender_values.append("male")
    else:
        price +=1
        gender_values.append("female")
    index1 += 1

###############################################################################################
# test_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/image_test/'
test_image_path = input_directory + 'image/'

# test_image_path_copy = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/test_image_copy/'
test_image_path_copy = str(Path.home()) + '/test_image_copy/'
if not os.path.exists(test_image_path_copy):
    os.mkdir(str(Path.home()) + '/test_image_copy')

# filtered_test_img_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/filtered_test_image/'
filtered_test_img_path = str(Path.home()) + '/filtered_test_image/'
if not os.path.exists(filtered_test_img_path):
    os.mkdir(str(Path.home()) + '/filtered_test_image')

# second_filtered_test_img_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/frontalface_alt_4_and_eye_filtered_test_image/'
second_filtered_test_img_path = str(Path.home()) + '/frontalface_alt_4_and_eye_filtered_test_image/'
if not os.path.exists(second_filtered_test_img_path):
    os.mkdir(str(Path.home()) + '/frontalface_alt_4_and_eye_filtered_test_image')

test_images = glob(os.path.join(test_image_path, '*.jpg'))

for img in test_images:
    image_name = os.path.basename(img)
    shutil.copy(os.path.join(test_image_path, image_name), os.path.join(test_image_path_copy, image_name))

copy_test_images = glob(os.path.join(test_image_path_copy, '*.jpg'))

print("Done image copy")

isolated_img_arr = []


# Create a CascadeClassifier Object
# classifier_arr = ["C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt_tree.xml", 
#                   "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt2.xml", 
#                   "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt.xml", 
#                   "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_default.xml"]
classifier_arr = ["/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt_tree.xml", 
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt2.xml",  
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt.xml", 
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_default.xml"]



# Three nested-for loop to get all detectable images by using frontal face alt 4 classifiers
for classifier in classifier_arr:
    face_cascade = cv2.CascadeClassifier(classifier)

    count = 0
    # print(training_images)
    for img in copy_test_images:
        image_name = os.path.basename(img)
        img = cv2.imread(img, 0)
        count += 1
        # print(count)
        
        whether_there_face = False
        for minNei in range(5, 0 ,-1): 
             faces = face_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
             # print(count, " Faces Length: ", len(faces))
             if(len(faces) == 1):
                whether_there_face = True

                face_x, face_x_plus_w, face_w, face_y_plus_h = 0, 0, 0, 0
                for x, y, w, h in faces:
                    cv2.rectangle(img, (x,y), (x+w, y+h), (0,255,0), 3)
                    cropped_face = img[y:y+h, x:x+w].copy()
                    cropped_face= cv2.resize(cropped_face, (100, 100))
                    scipy.misc.imsave(filtered_test_img_path + image_name, cropped_face)

        if whether_there_face:
            os.remove(test_image_path_copy + image_name)
        whether_there_face = False

# The remaining undetectable images
count = 0
undetectable_test_images = glob(os.path.join(test_image_path_copy, '*.jpg'))
for img in undetectable_test_images:
    image_name = os.path.basename(img)
    image_name = image_name[:-4]
    isolated_img_arr.append(image_name)
    count += 1

# shutil.rmtree(test_image_path_copy, ignore_errors=True)


# Now use one more eye classifier on top of frontal face alt 4 classifiers
# eye_cascade = cv2.CascadeClassifier("C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_eye.xml")
eye_cascade = cv2.CascadeClassifier('/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_eye.xml')

filtered_test_images = glob(os.path.join(filtered_test_img_path, '*.jpg'))

for img in filtered_test_images:
    image_name = os.path.basename(img)
    img = cv2.imread(img, 0)

    whether_there_eye = False
    for minNei in range(5, 3 ,-1): 
        eyes = eye_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
        if(len(eyes) > 0):
            shutil.copy(os.path.join(filtered_test_img_path, image_name), os.path.join(second_filtered_test_img_path, image_name))
            whether_there_eye = True

    if whether_there_eye:
        os.remove(filtered_test_img_path + image_name)
    whether_there_eye = False

# The remaining undetectable images
second_undetectable_test_images = glob(os.path.join(filtered_test_img_path, '*.jpg'))
for img in second_undetectable_test_images:
    image_name = os.path.basename(img)
    image_name = image_name[:-4]
    isolated_img_arr.append(image_name)

# shutil.rmtree(filtered_test_img_path, ignore_errors=True)
##################################################################################################
CATEGORIES = ['male', 'female']


def prepare(filepath):
    IMG_SIZE = 50
    img_array = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
    new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
    return new_array.reshape(-1, IMG_SIZE, IMG_SIZE, 1) 


# model = tf.keras.models.load_model("size_50_frontal_face_with_eye_filtered_image_128_64_64_conv_wiht_64_1_dense_with_dropout_and_epochs_10_batch_size_50.model")
model = tf.keras.models.load_model("image_training_model_epochs_10.model")
# The for loop is to get the size of the test data
# And use the result to initialize the list size.
test_image_count = 0
for img in os.listdir(test_image_path):
    test_image_count += 1

# Use the test_image_count here from above for loop
w, h = 2, test_image_count
testDataList = [[0 for x in range(w)] for y in range(h)]

# Reset the test_image_test to zero.
test_image_count = 0

# count = 0
# for loop to loop every image in the directory
for img in os.listdir(second_filtered_test_img_path):

        # Manipulate the name of file and put it into list
        # the name id userid
        image_name = os.path.basename(img)
        image_name = image_name[:-4]
        testDataList[test_image_count][0] = image_name

        # Manipulate the gender and put it into list to match the
        # corresponding userid
        img = second_filtered_test_img_path + img

        # I believe it is a 3D array.
        prediction = model.predict([prepare(img)])

        # Get the gender out of 3D array.
        gender = CATEGORIES[int(prediction[0][0])]

        # Put the gender into list.
        testDataList[test_image_count][1] = gender

        # Increment the test_image_count every round.
        test_image_count += 1
        # count += 1
# print("detectable image count: ", count)
#print("Detectable image count:", test_image_count)
# print("isolated_img_arr length: ", len(isolated_img_arr))
# print(test_image_count)
count = 0
for img in isolated_img_arr:
    testDataList[test_image_count][0] = img
    testDataList[test_image_count][1] = 'NULL'

    # Increment the test_image_count every round.
    test_image_count += 1
    count += 1

#print("Undetectable image count: ", count)
#print("total image count: ", test_image_count)


# print(testDataList)
# print(len(testDataList))
###############################################################################################

###############################################################################################


#Parsing through the test data
with open(profile_test) as csvfile:
        testreader = csv.reader(csvfile,delimiter=',')
        header = next(testreader)
        
        w, h = 2, test_image_count
        testDataListFromTianyi = [[0 for x in range(w)] for y in range(h)]

        count = 0
        for row_1 in testreader:
        	testDataListFromTianyi[count][0] = row_1[1]
        	testDataListFromTianyi[count][1] = gender_values[count]
        	count += 1

        for img in range(len(testDataListFromTianyi)):
        	for row_2 in range(len(testDataList)):
        		if ((testDataListFromTianyi[img][0] == testDataList[row_2][0]) and (testDataList[row_2][1] == 'NULL')):
        			testDataList[row_2][1] = testDataListFromTianyi[img][1]
        #print("test data list: ")
        for img in range(len(testDataList)):
            if(testDataList[img][1] == 'NULL'):
                print('NULLl')
        #print("Check test data list no null")
        # print(testDataList)

        for img in range(len(testDataListFromTianyi)):
        	for row_3 in range(len(testDataList)):
        		if (testDataListFromTianyi[img][0] == testDataList[row_3][0]):
        			testDataListFromTianyi[img][1] = testDataList[row_3][1]
        # print("test data list from Tianyi: ")
        # print(testDataListFromTianyi)
        # print()
        # print()
csvfile.close();

with open(profile_test) as csvfile:
        testreader = csv.reader(csvfile,delimiter=',')
        header = next(testreader)
        index2 = 0

        for row in testreader:
            root = et.Element('user', id=row[1], age_group=age_values[index2],
                              # gender='l', extrovert='3.49',
                             # gender=gender_values[index2], extrovert='3.49',
                             gender=testDataListFromTianyi[index2][1], extrovert='3.49',
                              neurotic='2.73', agreeable='3.58', 
                              conscientious='3.45', open='3.91')

            #print([row[1], age_values[index2], 'l'])
   
            tree = et.ElementTree(root)
            folder_name = output_directory + row[1] + ".xml"
            tree.write(folder_name)
            index2 += 1

shutil.rmtree(str(Path.home()) + filtered_test_img_path, ignore_errors=True)
shutil.rmtree(filtered_test_img_path, ignore_errors=True)
shutil.rmtree(str(Path.home()) + test_image_path_copy, ignore_errors=True)
shutil.rmtree(test_image_path_copy, ignore_errors=True)
shutil.rmtree(str(Path.home()) + second_filtered_test_img_path, ignore_errors=True)
shutil.rmtree(second_filtered_test_img_path, ignore_errors=True)

print('Done')

csvfile.close();



