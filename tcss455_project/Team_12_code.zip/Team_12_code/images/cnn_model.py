import csv
import os
import shutil
from glob import glob
import numpy as np
import matplotlib.pyplot as plt
import cv2
import random
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten
from keras.layers import BatchNormalization
from keras.layers.convolutional import Conv2D
from keras.layers.convolutional import MaxPooling2D
from sklearn.model_selection import train_test_split
from keras import backend as K
from keras.callbacks import TensorBoard
import time
import shutil
from keras.preprocessing.image import ImageDataGenerator


# NAME = 'Male-vs-female-cnn-128-64-64-conv-with-dropout-64-1-dense-{}'.format(int(time.time()))

# tensorboard = TensorBoard(log_dir='logs/{}'.format(NAME))


# Arrays for userid, age and gender in training profile csv
userIDArray = []
ageArray =[]
genderArray =[]

print("Begin")

# image_folder_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/image/'
image_folder_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/2st_layer_eye_minNeighbor_5_to_3/'
main_folder_path ='C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/'
training_profile_path = open('C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/profile.csv')
# training_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/image/'
training_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/2st_layer_eye_minNeighbor_5_to_3/'
male_folder_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/male/'
female_folder_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/female/'
training_images = glob(os.path.join(training_image_path, '*.jpg'))


if not os.path.exists(male_folder_path):
	os.mkdir('male')
if not os.path.exists(female_folder_path):
	os.mkdir('female')

def sortByUserID(elem):
    return elem[0]

img_name_array = []
for img in training_images:
    image_name = os.path.basename(img)
    image_name = image_name[:-4]
    img_name_array.append(image_name)


with training_profile_path as csvfile:
    readCSV = csv.reader(csvfile, delimiter = ',')

    # skip the first row
    next(csvfile)

    # row_count is counting the total of training targets
    row_count = 0

    for row in readCSV:
        userid = row[1]
        for index in range(len(img_name_array)):
            if(userid == img_name_array[index]):
                age = row[2]
                gender = row[3]

                userIDArray.append(userid)
                ageArray.append(age)
                genderArray.append(gender)

                row_count += 1
    # print(row_count)

    training_profile_list_w, training_profile_list_h = 3, row_count
    training_profile_list = [[0 for x in range(training_profile_list_w)] for y in range(training_profile_list_h)]

    for row in range(row_count):
        training_profile_list[row][0] = userIDArray[row]
        training_profile_list[row][1] = "%.0f" % float(ageArray[row])
        training_profile_list[row][2] = "%.0f" % float(genderArray[row])

    training_profile_list.sort(key=sortByUserID) 

    # training_profile_list_row_index 
    row_index = 0


    for img in training_images:
        image_name = os.path.basename(img)
        image_name = image_name[:-4]
        if(training_profile_list[row_index][2] == '1'):
        	# os.path.join(file_path, 'female', img)
        	image_name = image_name + ".jpg"
        	# for image_name in source:	
        	shutil.copy(os.path.join(image_folder_path, image_name), os.path.join(female_folder_path, image_name))
        else:
        	image_name = image_name + ".jpg"
        	# for image_name in source:
        	shutil.copy(os.path.join(image_folder_path, image_name), os.path.join(male_folder_path, image_name))
        row_index += 1

csvfile.close()
    
###############################################################################################    


TRAIN_DATA = main_folder_path
CATEGORIES = ['male', 'female']
IMG_SIZE = 50
training_data = []

def create_training_data():
	for category in CATEGORIES:
		path = os.path.join(TRAIN_DATA, category) # path to female or male dir
		class_num = CATEGORIES.index(category)

		for img in os.listdir(path):
			try:
				img_array = cv2.imread(os.path.join(path,img), cv2.IMREAD_GRAYSCALE)
				new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
				training_data.append([new_array, class_num])
			except Exception as e:
				pass

create_training_data()
random.shuffle(training_data)

X = []
y = []

for features, label in training_data:
	X.append(features)
	y.append(label)

# first parameter is how many features do we have,
# -1 is kind of catch everything, 
# second and third parameter is size by size
# fourth parameter is grayscale 
X = np.array(X).reshape(-1, IMG_SIZE, IMG_SIZE, 1) 
# X = np.array(X).reshape(-1, IMG_SIZE, IMG_SIZE, 3) 

# First split the data in two sets, 80% for training, 20% for Val/Test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1, stratify=y)


# pickle_out = open("X.pickle", "wb")
# pickle.dump(X, pickle_out)
# pickle_out.close()

# pickle_out = open("y.pickle", "wb")
# pickle.dump(y, pickle_out)
# pickle_out.close()

# pickle_in = open("X.pickle", "rb")
# X = pickle.load(pickle_in)


###############################################################################################    

X_train =  X_train / 255
X_test = X_test / 255

def train_model():


	# create model
    model = Sequential()

    # Input layer
	# Convolutional layer with 128 feature maps of size 3x3.
    model.add(Conv2D(128, (3, 3), input_shape=(IMG_SIZE, IMG_SIZE, 1), activation='relu'))

	# Pooling layer taking the max over 2*2 patches.
    model.add(MaxPooling2D(pool_size=(2, 2)))

	# Convolutional layer with 64 feature maps of size 3×3.
    model.add(Conv2D(64, (3, 3), activation='relu'))

	# Pooling layer taking the max over 2*2 patches.
    model.add(MaxPooling2D(pool_size=(2, 2)))

	# Convolutional layer with 64 feature maps of size 3×3.
    model.add(Conv2D(64, (3, 3), activation='relu'))

	# Pooling layer taking the max over 2*2 patches.
    model.add(MaxPooling2D(pool_size=(2, 2)))

	# Dropout layer with a probability of 20%.
    model.add(Dropout(0.2))

	# Flatten layer.
    model.add(Flatten())

    # Fully connected layer with 64 neurons and rectifier activation.
    model.add(Dense(64, activation='relu'))

    # Output layer
    model.add(Dense(1, activation='sigmoid'))

    # Compile model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    return model

# build the model
model = train_model()

# Fit the model
# model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50, callbacks=[tensorboard])

model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=10, batch_size=50)

# datagen = ImageDataGenerator(rotation_range=90, horizontal_flip=True, vertical_flip=True)
# model.fit_generator(datagen.flow(X_train, y_train, batch_size=50), validation_data=(X_test, y_test), steps_per_epoch=160, epochs=10)

# Final evaluation of the model
scores = model.evaluate(X_test, y_test, verbose=0)
print("Large CNN Error: %.2f%%" % (100-scores[1]*100))
 
model.save('image_training_model_epochs_10.model')


shutil.rmtree(male_folder_path, ignore_errors=True)
shutil.rmtree(female_folder_path, ignore_errors=True)