import cv2
from glob import glob
import os
import scipy.misc
import shutil


print("Begin")

copy_training_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/training_image_copy/'
if not os.path.exists(copy_training_image_path):
    os.mkdir('training_image_copy')

filtered_training_img_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/1st_layer_frontalface_alt_4_minNeighbor_5_to_0/'
if not os.path.exists(filtered_training_img_path):
    os.mkdir('1st_layer_frontalface_alt_4_minNeighbor_5_to_0/')

training_image_path = 'C:/Users/BunBun/Documents/TCSS 455 Machine Learning/Image tutorial with KERAS with tensorflow as backend/final version/image/'

training_images = glob(os.path.join(training_image_path, '*.jpg'))

for img in training_images:
    image_name = os.path.basename(img)
    shutil.copy(os.path.join(training_image_path, image_name), os.path.join(copy_training_image_path, image_name))

copy_training_images = glob(os.path.join(copy_training_image_path, '*.jpg'))

print("Done image copy")

classifier_arr = ["C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt_tree.xml", 
                  "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt2.xml", 
                  "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_alt.xml", 
                  "C:/Users/BunBun/AppData/Local/Programs/Python/Python36/Lib/site-packages/cv2/data/haarcascade_frontalface_default.xml"]

classifier_arr_2 = ["haarcascade_frontalface_alt_tree.xml", "haarcascade_frontalface_alt2.xml",
                    "haarcascade_frontalface_alt.xml", "haarcascade_frontalface_default.xml"]

classifier_arr_2_count = 0
for classifier in classifier_arr:
# Create a CascadeClassifier Object
    face_cascade = cv2.CascadeClassifier(classifier)

    # count = 0
    print("Now use", classifier_arr_2[classifier_arr_2_count], "to filter images in training data set.")
    classifier_arr_2_count += 1
    # print(training_images)
    for img in copy_training_images:
        image_name = os.path.basename(img)
        img = cv2.imread(img, 0)
        # count += 1
        # print(count)

        whether_there_face = False
        for minNei in range(5, 0 ,-1): 
             faces = face_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
             # print(count, " Faces Length: ", len(faces))
             if(len(faces) == 1):
                whether_there_face = True

                # face_x, face_x_plus_w, face_w, face_y_plus_h = 0, 0, 0, 0
                for x, y, w, h in faces:
                    # rectangle - method to create the face rectangle
                    # img - image object
                    # (x,y), (x+w, y+h) - rectangle outline
                    # (0,255,0) - RGB value of rectangle 
                    # 3 - width of the rectangle
                    cv2.rectangle(img, (x,y), (x+w, y+h), (0,255,0), 3)
                    cropped_face = img[y:y+h, x:x+w].copy()
                    cropped_face= cv2.resize(cropped_face, (100, 100))

                    scipy.misc.imsave(filtered_training_img_path + image_name, cropped_face)

        if whether_there_face:
            # print("So, remove: ", image_name, " count: ", count)
            os.remove(copy_training_image_path + image_name)
        whether_there_face = False