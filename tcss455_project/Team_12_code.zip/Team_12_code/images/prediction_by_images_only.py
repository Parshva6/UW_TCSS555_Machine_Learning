import cv2
from glob import glob
import os
import scipy.misc

import os
import tensorflow as tf
import xml.etree.ElementTree as et
import sys
import shutil
from pathlib import *

print("Begin")

input_path = sys.argv[1]
output_path = sys.argv[2]

test_image_path = input_path + 'image/'

test_image_path_copy = str(Path.home()) + '/test_image_copy/'
if not os.path.exists(test_image_path_copy):
    os.mkdir(str(Path.home()) + '/test_image_copy')

filtered_test_img_path = str(Path.home()) + '/filtered_test_image/'
if not os.path.exists(filtered_test_img_path):
    os.mkdir(str(Path.home()) + '/filtered_test_image')

second_filtered_test_img_path = str(Path.home()) + '/frontalface_alt_4_and_eye_filtered_test_image/'
if not os.path.exists(second_filtered_test_img_path):
    os.mkdir(str(Path.home()) + '/frontalface_alt_4_and_eye_filtered_test_image')

test_images = glob(os.path.join(test_image_path, '*.jpg'))

for img in test_images:
    image_name = os.path.basename(img)
    shutil.copy(os.path.join(test_image_path, image_name), os.path.join(test_image_path_copy, image_name))

copy_test_images = glob(os.path.join(test_image_path_copy, '*.jpg'))

print("Done image copy")

isolated_img_arr = []


# Create a CascadeClassifier Object
classifier_arr = ["/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt_tree.xml", 
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt2.xml",  
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_alt.xml", 
                  "/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_frontalface_default.xml"]



# Three nested-for loop to get all detectable images by using frontal face alt 4 classifiers
for classifier in classifier_arr:
    face_cascade = cv2.CascadeClassifier(classifier)

    count = 0
    # print(training_images)
    for img in copy_test_images:
        image_name = os.path.basename(img)
        img = cv2.imread(img, 0)
        count += 1
        # print(count)
        
        whether_there_face = False
        for minNei in range(5, 0 ,-1): 
             faces = face_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
             # print(count, " Faces Length: ", len(faces))
             if(len(faces) == 1):
                whether_there_face = True

                face_x, face_x_plus_w, face_w, face_y_plus_h = 0, 0, 0, 0
                for x, y, w, h in faces:
                    cv2.rectangle(img, (x,y), (x+w, y+h), (0,255,0), 3)
                    cropped_face = img[y:y+h, x:x+w].copy()
                    cropped_face= cv2.resize(cropped_face, (100, 100))
                    scipy.misc.imsave(filtered_test_img_path + image_name, cropped_face)

        if whether_there_face:
            os.remove(test_image_path_copy + image_name)
        whether_there_face = False

# The remaining undetectable images
count = 0
undetectable_test_images = glob(os.path.join(test_image_path_copy, '*.jpg'))
for img in undetectable_test_images:
    image_name = os.path.basename(img)
    image_name = image_name[:-4]
    isolated_img_arr.append(image_name)
    count += 1

# shutil.rmtree(test_image_path_copy, ignore_errors=True)


# Now use one more eye classifier on top of frontal face alt 4 classifiers
eye_cascade = cv2.CascadeClassifier('/usr/local/lib/python3.6/dist-packages/cv2/data/haarcascade_eye.xml')

filtered_test_images = glob(os.path.join(filtered_test_img_path, '*.jpg'))

for img in filtered_test_images:
    image_name = os.path.basename(img)
    img = cv2.imread(img, 0)

    whether_there_eye = False
    for minNei in range(5, 3 ,-1): 
        eyes = eye_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=minNei)
        if(len(eyes) > 0):
            shutil.copy(os.path.join(filtered_test_img_path, image_name), os.path.join(second_filtered_test_img_path, image_name))
            whether_there_eye = True

    if whether_there_eye:
        os.remove(filtered_test_img_path + image_name)
    whether_there_eye = False

# The remaining undetectable images
second_undetectable_test_images = glob(os.path.join(filtered_test_img_path, '*.jpg'))
for img in second_undetectable_test_images:
    image_name = os.path.basename(img)
    image_name = image_name[:-4]
    isolated_img_arr.append(image_name)

# shutil.rmtree(filtered_test_img_path, ignore_errors=True)
##################################################################################################
CATEGORIES = ['male', 'female']


def prepare(filepath):
    IMG_SIZE = 50
    img_array = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
    new_array = cv2.resize(img_array, (IMG_SIZE, IMG_SIZE))
    return new_array.reshape(-1, IMG_SIZE, IMG_SIZE, 1) 

model = tf.keras.models.load_model("image_training_model_epochs_10.model")
# The for loop is to get the size of the test data
# And use the result to initialize the list size.
test_image_count = 0
for img in os.listdir(test_image_path):
    test_image_count += 1

# Use the test_image_count here from above for loop
w, h = 2, test_image_count
testDataList = [[0 for x in range(w)] for y in range(h)]

# Reset the test_image_test to zero.
test_image_count = 0

# count = 0
# for loop to loop every image in the directory
for img in os.listdir(second_filtered_test_img_path):

        # Manipulate the name of file and put it into list
        # the name id userid
        image_name = os.path.basename(img)
        image_name = image_name[:-4]
        testDataList[test_image_count][0] = image_name

        # Manipulate the gender and put it into list to match the
        # corresponding userid
        img = second_filtered_test_img_path + img

        # I believe it is a 3D array.
        prediction = model.predict([prepare(img)])

        # Get the gender out of 3D array.
        gender = CATEGORIES[int(prediction[0][0])]

        # Put the gender into list.
        testDataList[test_image_count][1] = gender

        # Increment the test_image_count every round.
        test_image_count += 1
        # count += 1
# print("detectable image count: ", count)
print("Detectable image count:", test_image_count)
# print("isolated_img_arr length: ", len(isolated_img_arr))
# print(test_image_count)
count = 0
for img in isolated_img_arr:
    testDataList[test_image_count][0] = img
    testDataList[test_image_count][1] = 'female'

    # Increment the test_image_count every round.
    test_image_count += 1
    count += 1

print("Undetectable image count: ", count)
print("total image count: ", test_image_count)


# print(testDataList)
# print(len(testDataList))


##################################################################################
# base_path = os.path.dirname(os.path.realpath(__file__))
# output xml file
for row in range(test_image_count):
    root = et.Element('user', id=testDataList[row][0], age_group='xx-24',
                      gender=testDataList[row][1], extrovert='3.49', 
                      neurotic='2.73', agreeable='3.58', 
                      conscientious='3.45', open='3.91')

    tree = et.ElementTree(root)
    folder_name = output_path + testDataList[row][0] + ".xml"
    tree.write(folder_name)

shutil.rmtree(str(Path.home()) + filtered_test_img_path, ignore_errors=True)
shutil.rmtree(filtered_test_img_path, ignore_errors=True)
shutil.rmtree(str(Path.home()) + test_image_path_copy, ignore_errors=True)
shutil.rmtree(test_image_path_copy, ignore_errors=True)
shutil.rmtree(str(Path.home()) + second_filtered_test_img_path, ignore_errors=True)
shutil.rmtree(second_filtered_test_img_path, ignore_errors=True)

print('Done')